Project management system Application

1) Introduction
This project management system [PMS] was developed for to track the current project status.
We can create a customer and we can update it if required and we can remove it.
We can create project under customers and keep tracking on projects.
Info like Project current status and we can view the discretion of the project 
And also we can get the basic details of the project.   

2) Pre-Requirements 
a) Windows Environment
b) Java Development Kit (JDK),version 8 or later
   Downlode link : http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html
c) Oracle : Oracle sql Developer
   Downlode link :http://www.oracle.com/technetwork/developer-tools/sql-developer/downloads/index.html
d) win-rar : 
   Downlode  link :http://www.win-rar.com/download.html?&L=0
 
3) Configuration
a) After Completion of installation of java and oracle database
b) Extract the PMS.zip
c) Update the config.properties file in the conf folder with your datbase credentials.
d) Update the PMS_DIR= current location of PMS project folder.

4)  Run 
a)  Run pms.cmd file 

5)  Support
a)  Phone:+91 7569667076
b)  Email:surapaneniharsha54@hotmail.com
